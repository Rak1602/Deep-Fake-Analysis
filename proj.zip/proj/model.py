import os
import cv2
import numpy as np
from skimage.feature import local_binary_pattern
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization, LeakyReLU
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import EarlyStopping

# Configuration
img_size = 64
epochs = 20
lbp_radius = 1
lbp_points = 8 * lbp_radius

def preprocess_image(img):
    img_resized = cv2.resize(img, (img_size, img_size))
    gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)

    # LBP
    lbp = local_binary_pattern(gray, lbp_points, lbp_radius, method='uniform')
    lbp = lbp.astype(np.float32)
    lbp /= (lbp.max() + 1e-6)
    lbp = np.expand_dims(lbp, axis=-1)

    # Sobel gradients
    grad_x = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)

    grad_x = cv2.normalize(grad_x, None, 0, 1, cv2.NORM_MINMAX)
    grad_y = cv2.normalize(grad_y, None, 0, 1, cv2.NORM_MINMAX)

    grad = np.stack((grad_x, grad_y), axis=-1)
    combined = np.concatenate([lbp, grad], axis=-1)
    return combined

def load_images_and_labels(folder, label):
    images, labels = [], []
    for filename in os.listdir(folder):
        img_path = os.path.join(folder, filename)
        img = cv2.imread(img_path)
        if img is not None:
            combined = preprocess_image(img)
            images.append(combined)
            labels.append(label)
    return np.array(images, dtype=np.float32), np.array(labels, dtype=np.float32)

# Paths
train_ai_folder = 'drive/MyDrive/rvf10k/train/fake'
train_real_folder = 'drive/MyDrive/rvf10k/train/real'
test_ai_folder = 'drive/MyDrive/rvf10k/valid/fake'
test_real_folder = 'drive/MyDrive/rvf10k/valid/real'

print("Loading data...")
X_train_ai, y_train_ai = load_images_and_labels(train_ai_folder, 1)
X_train_real, y_train_real = load_images_and_labels(train_real_folder, 0)
X_test_ai, y_test_ai = load_images_and_labels(test_ai_folder, 1)
X_test_real, y_test_real = load_images_and_labels(test_real_folder, 0)

X_train = np.concatenate([X_train_ai, X_train_real])
y_train = np.concatenate([y_train_ai, y_train_real])
X_test = np.concatenate([X_test_ai, X_test_real])
y_test = np.concatenate([y_test_ai, y_test_real])

# Shuffle
idx = np.random.permutation(len(X_train))
X_train, y_train = X_train[idx], y_train[idx]

# Data Augmentation
datagen = ImageDataGenerator(
    rotation_range=10,
    width_shift_range=0.1,
    height_shift_range=0.1,
    zoom_range=0.1
)
datagen.fit(X_train)

# Model
model = Sequential([
    Conv2D(32, (3, 3), padding='same', input_shape=(img_size, img_size, 3)),
    BatchNormalization(),
    LeakyReLU(),
    MaxPooling2D(2, 2),

    Conv2D(64, (3, 3), padding='same'),
    BatchNormalization(),
    LeakyReLU(),
    MaxPooling2D(2, 2),

    Conv2D(128, (3, 3), padding='same'),
    BatchNormalization(),
    LeakyReLU(),
    MaxPooling2D(2, 2),

    Flatten(),
    Dense(256),
    LeakyReLU(),
    Dropout(0.5),

    Dense(1, activation='sigmoid')
])

model.compile(optimizer=Adam(learning_rate=0.0003),
              loss='binary_crossentropy',
              metrics=['accuracy'])

# Early stopping
early_stop = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

# Train
model.fit(datagen.flow(X_train, y_train, batch_size=32),
          epochs=epochs,
          validation_data=(X_test, y_test),
          callbacks=[early_stop])

# Evaluate
loss, acc = model.evaluate(X_test, y_test)
print(f"Test Accuracy: {acc:.4f}")

# Save
model.save("improved_LBP_Sobel_AI_classifier.keras")
print("Model saved as improved_LBP_Sobel_AI_classifier.keras")
