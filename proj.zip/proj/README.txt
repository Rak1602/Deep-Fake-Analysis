Run all these files in colab for better environment.
The files must be ran in this order:
1.model.py
2.metrics.py
3.roc.py
4.predict.py

The dataset is from Kaggle and the link is: 
https://www.kaggle.com/datasets/sachchitkunichetty/rvf10k