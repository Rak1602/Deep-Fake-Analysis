import cv2
import numpy as np
from skimage.feature import local_binary_pattern
from tensorflow.keras.models import load_model

# Load model
model = load_model("improved_LBP_Sobel_AI_classifier.keras")

# Config
img_size = 64
lbp_radius = 1
lbp_points = 8 * lbp_radius

# Preprocess function (same as training)
def preprocess_image(img):
    img_resized = cv2.resize(img, (img_size, img_size))
    gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)

    # LBP
    lbp = local_binary_pattern(gray, lbp_points, lbp_radius, method='uniform')
    lbp = lbp.astype(np.float32)
    lbp /= (lbp.max() + 1e-6)
    lbp = np.expand_dims(lbp, axis=-1)

    # Sobel gradients
    grad_x = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    grad_x = cv2.normalize(grad_x, None, 0, 1, cv2.NORM_MINMAX)
    grad_y = cv2.normalize(grad_y, None, 0, 1, cv2.NORM_MINMAX)
    grad = np.stack((grad_x, grad_y), axis=-1)

    combined = np.concatenate([lbp, grad], axis=-1)
    return combined

# Predict function
def predict_image(img_path):
    img = cv2.imread(img_path)
    if img is None:
        print("Image not found or can't be opened.")
        return

    processed = preprocess_image(img)
    processed = np.expand_dims(processed, axis=0)  # Add batch dimension

    prob = model.predict(processed)[0][0]
    label = "FAKE" if prob < 0.05 or prob>0.5 else "REAL"

    print(f"Prediction: {label} ({prob:.4f})")

# Example usage
predict_image("/content/deepfake1.jpg")
