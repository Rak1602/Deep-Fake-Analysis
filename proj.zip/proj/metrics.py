from sklearn.metrics import classification_report, confusion_matrix

# Get model predictions
y_pred_prob = model.predict(X_test)
y_pred = (y_pred_prob > 0.5).astype("int32")

# Classification Report
print("Classification Report:\n", classification_report(y_test, y_pred, digits=4))

# Confusion Matrix
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))